package com.bottlr.utils;

import com.bottlr.dataacess.BottleDetails;

public class URLs {

	//public static String BASE_URL = "http://184.107.155.35:8080/";
	//public static String BOTTLE_URL = BASE_URL + "getBotls";
	
//	public static String BASE_URL = "http://testbotl.com:8080/";
	
	public static String BASE_URL = "http://botl.com/";
	public static String BOTTLE_KING_OLD_BOTTLE_URL = BASE_URL + "getBotls/";
	public static String BOTTLE_KING_NEW_BOTTLE_URL = BASE_URL + "getRecentBotls/";
	
	
	
	public static String USER_OLD_BOTTLE_URL = BASE_URL + "getUserBotls/515/";
	public static String USER_NEW_BOTTLE_URL = BASE_URL + "getUserRecentBotls/515/";
	
	
	
	public static String BOTTLE_URL_AUDIO_API = BASE_URL + "getAudioUrl/";
	
	public static String BOTTLE_DIRECT_AUDIO_BASE_URL = "http://c801462.r62.cf2.rackcdn.com/";
	
	//Youtube
	public static String YOUTUBE_BASEURL = "http://www.youtube.com/watch?v=";
	public static String YOUTUBE_THUMB_URLBASE = "http://i1.ytimg.com/vi/"; 
	public static String YOUTUBE_THUMB_URLEND = "/default.jpg";
	
	
	
	//Social cam
	//Viddy
	//Vimeo
	//soundcloud
	
	
	public static String HEADImageBaseURL = "http://c801459.r59.cf2.rackcdn.com/";
	public static String HEADImageENDURL = "_large.jpg";
	
	public static String AvatarImageBaseURL = "http://c801458.r58.cf2.rackcdn.com/";
	
	
}
